"""Tests for the Flask app. MongoDB Atlas is replaced by an in-memory mongomock
collection so the tests run without internet or credentials."""
import mongomock
from pymongo.errors import ServerSelectionTimeoutError

import app as app_module

client = app_module.app.test_client()


def test_api():
    r = client.get("/api")
    assert r.status_code == 200 and r.is_json
    assert isinstance(r.get_json(), list) and len(r.get_json()) > 0
    print("PASS /api returns JSON list:", r.get_json()[0])


def test_success():
    col = mongomock.MongoClient().db.col
    app_module.get_collection = lambda: col
    r = client.post("/", data={"name": "Hema", "email": "h@x.com", "message": "Hi"})
    assert r.status_code == 302 and r.headers["Location"].endswith("/success")
    page = client.get("/success")
    assert b"Data submitted successfully" in page.data
    assert col.count_documents({}) == 1
    print("PASS valid submit -> 302 redirect to /success, message shown, 1 doc stored")


def test_validation_error():
    r = client.post("/", data={"name": "", "email": "", "message": ""})
    assert r.status_code == 400 and b"All fields are required." in r.data
    print("PASS empty fields -> same page, error shown, no redirect")


def test_db_error():
    def boom():
        raise ServerSelectionTimeoutError("Could not connect to MongoDB Atlas")
    app_module.get_collection = boom
    r = client.post("/", data={"name": "Hema", "email": "h@x.com", "message": "Hi"})
    assert r.status_code == 500 and b"Could not connect to MongoDB Atlas" in r.data
    assert b'value="Hema"' in r.data
    print("PASS database failure -> same page, error shown, input kept, no redirect")


def test_missing_uri():
    app_module.MONGO_URI = ""
    import importlib
    # restore the real get_collection to check the missing-URI branch
    importlib.reload(app_module)
    app_module.MONGO_URI = ""
    c = app_module.app.test_client()
    r = c.post("/", data={"name": "a", "email": "a@a.com", "message": "m"})
    assert r.status_code == 500 and b"MONGO_URI is not set" in r.data
    print("PASS missing MONGO_URI -> same page, clear error")


if __name__ == "__main__":
    for t in (test_api, test_success, test_validation_error, test_db_error, test_missing_uri):
        t()
    print("All tests passed")

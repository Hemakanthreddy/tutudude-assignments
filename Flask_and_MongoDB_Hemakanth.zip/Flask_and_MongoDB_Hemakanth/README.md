# Flask and MongoDB Atlas

- `/api` returns a JSON list read from `data.json`.
- `/` shows a form; valid submissions are inserted into MongoDB Atlas and redirect to `/success` ("Data submitted successfully"). Errors are shown on the same page.

## Run
1. `pip install -r requirements.txt`
2. Copy `.env.example` to `.env` and set `MONGO_URI` (Atlas: Connect > Drivers; allow your IP under Network Access).
3. `python app.py` and open http://127.0.0.1:5000/ and http://127.0.0.1:5000/api
4. Optional tests (no Atlas needed): `pip install mongomock` then `python test_app.py`

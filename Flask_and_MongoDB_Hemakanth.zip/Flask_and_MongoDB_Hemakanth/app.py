"""Flask app: JSON API route (Task 1) and a form that stores data in MongoDB Atlas (Task 2)."""
import json
import os

from dotenv import load_dotenv
from flask import Flask, jsonify, redirect, render_template, request, url_for
from pymongo import MongoClient
from pymongo.errors import PyMongoError

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data.json")

app = Flask(__name__)

MONGO_URI = os.environ.get("MONGO_URI", "")
DB_NAME = os.environ.get("DB_NAME", "flask_db")
COLLECTION_NAME = os.environ.get("COLLECTION_NAME", "submissions")


def get_collection():
    """Connect to MongoDB Atlas and return the collection.
    Raises an error if MONGO_URI is missing or the server cannot be reached."""
    if not MONGO_URI:
        raise RuntimeError("MONGO_URI is not set. Add it to your .env file.")
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    return client[DB_NAME][COLLECTION_NAME]


# ---------- Task 1: JSON API route ----------
@app.route("/api")
def api():
    """Read the list from the backend file (data.json) and return it as JSON."""
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        return jsonify({"error": f"Could not read data file: {e}"}), 500
    return jsonify(data)


# ---------- Task 2: Form + MongoDB Atlas ----------
@app.route("/", methods=["GET", "POST"])
def form():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()

        # Validation error -> show on the same page, no redirect
        if not name or not email or not message:
            return render_template(
                "form.html", error="All fields are required.",
                name=name, email=email, message=message), 400

        try:
            get_collection().insert_one(
                {"name": name, "email": email, "message": message})
        except (PyMongoError, RuntimeError) as e:
            # Database error -> show on the same page, no redirect
            return render_template(
                "form.html", error=f"Error: {e}",
                name=name, email=email, message=message), 500

        # Success -> redirect to another page
        return redirect(url_for("success"))

    return render_template("form.html")


@app.route("/success")
def success():
    return render_template("success.html")


if __name__ == "__main__":
    app.run(debug=True)

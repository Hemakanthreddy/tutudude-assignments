import json
import os

from flask import Flask, jsonify, render_template, request
from pymongo import MongoClient

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# MongoDB connection (override with the MONGO_URI environment variable)
mongo_client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
todo_collection = mongo_client["todo_db"]["items"]


# ----------------------------------------------------------------------
# Pages
# ----------------------------------------------------------------------
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/todo")
def todo():
    return render_template("todo.html")


# ----------------------------------------------------------------------
# API
# ----------------------------------------------------------------------
@app.route("/api")
def api():
    """Return the contents of data.json as JSON."""
    with open(os.path.join(BASE_DIR, "data.json"), encoding="utf-8") as f:
        return jsonify(json.load(f))


@app.route("/submittodoitem", methods=["POST"])
def submit_todo_item():
    """Store a To-Do item (itemName, itemDescription) in MongoDB."""
    payload = request.get_json(silent=True) or request.form
    item_name = payload.get("itemName")
    item_description = payload.get("itemDescription")

    if not item_name or not item_description:
        return jsonify({"error": "itemName and itemDescription are required"}), 400

    result = todo_collection.insert_one(
        {"itemName": item_name, "itemDescription": item_description}
    )
    return jsonify({"message": "To-Do item stored", "id": str(result.inserted_id)}), 201


if __name__ == "__main__":
    app.run(debug=True)

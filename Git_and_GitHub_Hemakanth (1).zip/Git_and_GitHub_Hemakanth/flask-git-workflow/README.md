# Flask Git Workflow

Practice repository for the Git & GitHub assignment (SSH, branching, merging,
conflict resolution, sequential commits, `git reset` and `git rebase`).

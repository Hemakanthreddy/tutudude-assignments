"""Smoke test: routes respond and /submittodoitem stores data (MongoDB mocked)."""
import os, sys
sys.path.insert(0, os.getcwd())
sys.dont_write_bytecode = True
import mongomock

import app as flask_app

client = flask_app.app.test_client()
print("GET /api        ->", client.get("/api").status_code, client.get("/api").get_json())
print("GET /todo       ->", client.get("/todo").status_code)

flask_app.todo_collection = mongomock.MongoClient()["todo_db"]["items"]
r = client.post("/submittodoitem", data={"itemName": "Buy milk", "itemDescription": "2 litres"})
print("POST /submittodoitem ->", r.status_code, r.get_json())
print("Stored documents:", [{k: v for k, v in d.items() if k != "_id"} for d in flask_app.todo_collection.find()])
r = client.post("/submittodoitem", json={"itemName": "only name"})
print("POST (missing field) ->", r.status_code, r.get_json())

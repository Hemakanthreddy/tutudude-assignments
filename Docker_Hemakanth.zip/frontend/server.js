const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
// In Docker Compose the backend is reachable by its service name.
const BACKEND_URL = process.env.BACKEND_URL || "http://backend:5000";

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// Form page. An error (if any) is passed in the query string by the redirect below.
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Send the form data to the Flask backend.
app.post("/submit", async (req, res) => {
  try {
    const response = await fetch(`${BACKEND_URL}/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body),
    });
    const result = await response.json();

    if (response.ok && result.success) {
      return res.redirect("/success.html");          // success: another page
    }
    // error from the backend: stay on the form and show it
    return res.status(response.status).send(renderForm(result.error || "Something went wrong.", req.body));
  } catch (err) {
    return res.status(502).send(renderForm("Could not reach the backend: " + err.message, req.body));
  }
});

const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function renderForm(error, v = {}) {
  const fs = require("fs");
  let html = fs.readFileSync(path.join(__dirname, "public", "index.html"), "utf8");
  html = html.replace("<!--ERROR-->", `<div class="error">${esc(error)}</div>`);
  html = html.replace('id="name" name="name" value=""', `id="name" name="name" value="${esc(v.name)}"`);
  html = html.replace('id="email" name="email" value=""', `id="email" name="email" value="${esc(v.email)}"`);
  html = html.replace("></textarea>", `>${esc(v.message)}</textarea>`);
  return html;
}

app.listen(PORT, "0.0.0.0", () => console.log(`Frontend running on port ${PORT}, backend at ${BACKEND_URL}`));

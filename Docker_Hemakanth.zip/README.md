# Dockerized Express + Flask app

- `frontend/` - Node.js/Express app with the form (port 3000)
- `backend/` - Flask app that handles the submission (port 5000)
- `docker-compose.yaml` - runs both on one network (`app-network`)

## Run
    docker compose up --build
Open http://localhost:3000

## Push images to Docker Hub
    docker login
    docker push <dockerhub-username>/flask-backend:latest
    docker push <dockerhub-username>/express-frontend:latest
(Change the `image:` names in docker-compose.yaml to your Docker Hub username first.)

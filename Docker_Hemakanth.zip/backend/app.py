"""Flask backend: receives the form submission from the Express frontend and processes it."""
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)


@app.route("/")
def health():
    return jsonify({"status": "backend is running"})


@app.route("/submit", methods=["POST"])
def submit():
    data = request.get_json(silent=True) or request.form
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    message = (data.get("message") or "").strip()

    if not name or not email or not message:
        return jsonify({"success": False, "error": "All fields are required."}), 400
    if "@" not in email or "." not in email.split("@")[-1]:
        return jsonify({"success": False, "error": "Please enter a valid email address."}), 400

    # Process the data
    processed = {
        "name": name.title(),
        "email": email.lower(),
        "message": message,
        "message_length": len(message),
    }
    print("Received submission:", processed, flush=True)
    return jsonify({"success": True, "message": "Data submitted successfully", "data": processed})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

import os
import socket
from datetime import datetime, timezone

from flask import Flask, jsonify, request

app = Flask(__name__)

ITEMS = [
    {"id": 1, "name": "Arduino Uno", "category": "Microcontroller", "price": 550},
    {"id": 2, "name": "ESP32 DevKit", "category": "IoT Board", "price": 450},
    {"id": 3, "name": "DHT11 Sensor", "category": "Sensor", "price": 120},
    {"id": 4, "name": "HC-SR04 Ultrasonic", "category": "Sensor", "price": 90},
]

# In-memory store for form submissions (resets when the backend restarts).
SUBMISSIONS = []


@app.route("/health")
def health():
    return jsonify({
        "status": "ok",
        "host": socket.gethostname(),
        # Set by Jenkins when it deploys, so you can see which build is running.
        "build": os.getenv("BUILD_NUMBER", "manual"),
        # Shows that a secret from Jenkins credentials reached the app (value is never shown).
        "secret_configured": bool(os.getenv("APP_SECRET")),
    })


@app.route("/api/items")
def items():
    return jsonify(ITEMS)


@app.route("/api/submit", methods=["POST"])
def submit():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    message = str(data.get("message", "")).strip()
    if not name or not message:
        return jsonify({"error": "Name and message are required."}), 400
    entry = {
        "name": name,
        "message": message,
        "time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    SUBMISSIONS.append(entry)
    return jsonify({"message": "Data submitted successfully", "total": len(SUBMISSIONS)}), 201


@app.route("/api/submissions")
def submissions():
    return jsonify(SUBMISSIONS)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))

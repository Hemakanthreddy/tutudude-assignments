// pm2 process definition for the Flask backend (gunicorn on port 5000).
module.exports = {
  apps: [
    {
      name: "flask-backend",
      cwd: __dirname,
      script: "venv/bin/gunicorn",
      args: "--bind 0.0.0.0:5000 app:app",
      interpreter: "none",
      autorestart: true,
      env: {
        PORT: "5000",
        // These two come from the shell that runs pm2 (Jenkins sets them).
        BUILD_NUMBER: process.env.BUILD_NUMBER || "manual",
        APP_SECRET: process.env.APP_SECRET || "",
      },
    },
  ],
};

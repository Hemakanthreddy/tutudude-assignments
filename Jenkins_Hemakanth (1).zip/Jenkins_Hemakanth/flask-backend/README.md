# Flask backend (Jenkins CI/CD)

Endpoints: `/health`, `/api/items`, `POST /api/submit`, `/api/submissions`. Runs on port 5000 with gunicorn under pm2.

Files:
- `app.py`, `requirements.txt` - the application
- `test_app.py`, `requirements-dev.txt` - pytest tests (run by the pipeline)
- `ecosystem.config.js` - pm2 definition
- `Jenkinsfile` - pipeline: Checkout, Install dependencies, Test, Deploy (pm2 restart), Health check

Run locally:
```bash
python3 -m venv venv && . venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
pytest -v
python app.py
```

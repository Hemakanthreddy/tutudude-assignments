import pytest

from app import SUBMISSIONS, app


@pytest.fixture()
def client():
    SUBMISSIONS.clear()
    app.config["TESTING"] = True
    return app.test_client()


def test_health_is_ok(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.get_json()["status"] == "ok"


def test_items_returns_a_list(client):
    r = client.get("/api/items")
    assert r.status_code == 200
    items = r.get_json()
    assert isinstance(items, list) and len(items) >= 1
    assert {"id", "name", "category", "price"} <= set(items[0])


def test_submit_valid_message(client):
    r = client.post("/api/submit", json={"name": "Hemakanth", "message": "hello"})
    assert r.status_code == 201
    assert r.get_json()["message"] == "Data submitted successfully"
    assert len(client.get("/api/submissions").get_json()) == 1


def test_submit_rejects_empty_fields(client):
    r = client.post("/api/submit", json={"name": "", "message": ""})
    assert r.status_code == 400
    assert "error" in r.get_json()


def test_secret_is_never_leaked(client, monkeypatch):
    monkeypatch.setenv("APP_SECRET", "super-secret-value")
    body = client.get("/health").get_data(as_text=True)
    assert "super-secret-value" not in body
    assert client.get("/health").get_json()["secret_configured"] is True

#!/usr/bin/env bash
# Stops the apps that were started by hand in Part 1 (as ec2-user) so that Jenkins
# (user "jenkins") can run them from now on. Then makes pm2 start the jenkins-owned apps at boot.
# Run this ONCE, before the first Jenkins build.
set -euo pipefail

pm2 delete all || true
pm2 save --force
sudo env PATH="$PATH:$(dirname "$(command -v pm2)")" pm2 unstartup systemd -u "$USER" --hp "$HOME" || true

# pm2 for the jenkins user: auto-start its saved apps at boot.
sudo env PATH="$PATH:$(dirname "$(command -v pm2)")" pm2 startup systemd -u jenkins --hp /var/lib/jenkins

sudo mkdir -p /opt/apps
sudo chown -R jenkins:jenkins /opt/apps
echo "Done. Now run the two Jenkins pipelines."

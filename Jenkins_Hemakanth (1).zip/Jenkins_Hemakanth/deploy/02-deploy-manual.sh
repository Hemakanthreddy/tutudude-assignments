#!/usr/bin/env bash
# Part 1: deploy both apps by hand (clone, install, start with pm2).
# Usage:  bash 02-deploy-manual.sh <your-github-username>
set -euo pipefail
GH_USER="${1:?Usage: bash 02-deploy-manual.sh <github-username>}"
APPS="$HOME/apps"
mkdir -p "$APPS"
cd "$APPS"

# ---- Flask backend (port 5000) ----
[ -d flask-backend ] || git clone "https://github.com/$GH_USER/flask-backend.git"
cd flask-backend
git pull --ff-only
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
pm2 start ecosystem.config.js
cd "$APPS"

# ---- Express frontend (port 3000) ----
[ -d express-frontend ] || git clone "https://github.com/$GH_USER/express-frontend.git"
cd express-frontend
git pull --ff-only
npm install --omit=dev
pm2 start ecosystem.config.js

# ---- keep both alive after a reboot ----
pm2 save
sudo env PATH="$PATH:$(dirname "$(command -v pm2)")" pm2 startup systemd -u "$USER" --hp "$HOME"

sleep 3
pm2 list
echo "Flask  : $(curl -s http://localhost:5000/health)"
echo "Express: $(curl -s http://localhost:3000/health)"

#!/usr/bin/env bash
# Run once on a fresh Amazon Linux 2023 EC2 instance (as ec2-user).
# Installs Git, Python, Node.js, rsync and pm2, and adds swap for small instances.
set -euo pipefail

# 2 GB swap file: Jenkins needs more memory than a 1 GB t3.micro has.
if [ ! -f /swapfile ]; then
  sudo dd if=/dev/zero of=/swapfile bs=1M count=2048 status=progress
  sudo chmod 600 /swapfile
  sudo mkswap /swapfile
  sudo swapon /swapfile
  echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
fi

sudo dnf update -y
sudo dnf install -y git python3 python3-pip nodejs npm rsync
sudo npm install -g pm2

echo "---- versions ----"
python3 --version
pip3 --version
node --version
npm --version
git --version
pm2 --version
free -h | head -3

#!/usr/bin/env bash
# Shows what is running (handy for screenshots).
echo "== pm2 (jenkins user) =="; sudo -u jenkins env PATH="$PATH:/usr/local/bin" pm2 list 2>/dev/null || true
echo "== pm2 (ec2-user) ==";     pm2 list 2>/dev/null || true
echo "== Flask  ==";  curl -s http://localhost:5000/health; echo
echo "== Express =="; curl -s http://localhost:3000/health; echo
echo "== Jenkins ==";  systemctl is-active jenkins

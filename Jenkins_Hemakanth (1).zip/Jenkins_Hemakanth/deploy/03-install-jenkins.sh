#!/usr/bin/env bash
# Part 2: install Jenkins (LTS) on the same Amazon Linux 2023 instance.
set -euo pipefail

sudo wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat-stable/jenkins.repo
# dnf imports the signing key listed in jenkins.repo automatically (-y accepts it).
sudo dnf install -y fontconfig java-21-amazon-corretto-headless
sudo dnf install -y jenkins

# Folder where the pipelines deploy the apps, owned by the jenkins user.
sudo mkdir -p /opt/apps
sudo chown -R jenkins:jenkins /opt/apps

sudo systemctl daemon-reload
sudo systemctl enable --now jenkins
sleep 20
systemctl --no-pager status jenkins | head -5

echo
echo "Open  http://<EC2-PUBLIC-IP>:8080   (port 8080 must be open in the security group)"
echo "Unlock password:"
sudo cat /var/lib/jenkins/secrets/initialAdminPassword

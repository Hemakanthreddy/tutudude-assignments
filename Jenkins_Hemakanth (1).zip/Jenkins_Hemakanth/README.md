# Flask + Express on EC2 with a Jenkins CI/CD pipeline

```
Jenkins_Hemakanth/
|-- flask-backend/      push this folder to GitHub as its own repo  (has its own Jenkinsfile)
|-- express-frontend/   push this folder to GitHub as its own repo  (has its own Jenkinsfile)
|-- deploy/             helper scripts that run on the EC2 instance
|-- diagrams/architecture.png
`-- Jenkins_Documentation.docx
```

Everything runs on ONE EC2 instance: Flask on port 5000, Express on port 3000 (both kept alive by pm2) and Jenkins on port 8080.

## Part 1: deploy by hand

1. Push `flask-backend/` and `express-frontend/` to GitHub as two public repos with those names.
2. Launch an Amazon Linux 2023 EC2 instance (t3.small if free-tier eligible, otherwise t3.micro).
   Security group inbound: 22, 3000, 5000, 8080 (source Anywhere IPv4).
3. Connect (EC2 Instance Connect) and run:
   ```bash
   # copy the 3 scripts from deploy/ to the server, or paste their contents into files
   bash 01-install-prereqs.sh
   bash 02-deploy-manual.sh <your-github-username>
   ```
4. Open `http://<public-ip>:3000` (Express) and `http://<public-ip>:5000/health` (Flask).

## Part 2: Jenkins

1. `bash 03-install-jenkins.sh` then open `http://<public-ip>:8080`, unlock with the printed password,
   choose **Install suggested plugins**, create the admin user.
2. Manage Jenkins > Plugins > Available: install **NodeJS**, **Python**, **GitHub** (Git, Pipeline and GitHub Branch Source come with the suggested set).
3. `bash 04-handover-to-jenkins.sh` (stops the hand-started apps so Jenkins can own them).
4. Manage Jenkins > Credentials > System > Global > Add credential, kind **Secret text**:
   - ID `flask-app-secret`, secret: any text
   - ID `express-app-secret`, secret: any text
5. New Item > **Pipeline**, name `flask-backend-pipeline`:
   - Build Triggers: tick **GitHub hook trigger for GITScm polling**
   - Pipeline > Definition: **Pipeline script from SCM**, SCM **Git**, Repository URL `https://github.com/<user>/flask-backend.git`, Branch `*/main`, Script Path `Jenkinsfile`
   - Save > **Build Now**
6. Repeat for `express-frontend-pipeline` with the `express-frontend` repo.
7. GitHub webhook, in each repo: Settings > Webhooks > Add webhook:
   Payload URL `http://<public-ip>:8080/github-webhook/`, content type `application/json`, event "Just the push event".
8. Change something (for example the heading in `express-frontend/public/index.html`), `git push`, and watch both pipelines run by themselves.

## What each pipeline does

| Stage | Flask | Express |
|---|---|---|
| Checkout | pulls the latest code from GitHub | same |
| Install dependencies | `pip install -r requirements.txt` in a venv | `npm install` |
| Test | `pytest` (5 tests, report shown in Jenkins) | `npm test` (5 tests, Node test runner) |
| Deploy | copies to `/opt/apps/...`, installs, `pm2 startOrRestart` | same |
| Health check | `curl localhost:5000/health` | `curl localhost:3000/health` |

The secret text credentials are injected as the `APP_SECRET` environment variable (masked in the logs). `/health` shows `secret_configured: true` and the Jenkins `build` number, so you can see which build is live.

## Troubleshooting

| Problem | Fix |
|---|---|
| Jenkins page does not open | Port 8080 missing in the security group; `sudo systemctl status jenkins` |
| `NOKEY` / GPG error installing Jenkins | Re-run the script; dnf must import the key (use `sudo dnf install -y jenkins` and answer `y`) |
| Instance freezes while installing Jenkins | Too little memory: run `01-install-prereqs.sh` first (adds swap), or use t3.small |
| Build fails: `pm2: command not found` | `sudo npm install -g pm2`, then restart Jenkins: `sudo systemctl restart jenkins` |
| Build fails: `Could not find credentials entry` | Credential ID must be exactly `flask-app-secret` / `express-app-secret` |
| Port already in use / app not restarting | You skipped `04-handover-to-jenkins.sh` |
| Webhook shows a red cross | Check the Payload URL ends with `/github-webhook/` and port 8080 is open |
| Build does not start after a push | Tick "GitHub hook trigger for GITScm polling" in the job, run one manual build first |

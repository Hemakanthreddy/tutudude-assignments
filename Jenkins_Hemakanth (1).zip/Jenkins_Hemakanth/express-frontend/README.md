# Express frontend (Jenkins CI/CD)

Serves the web page on port 3000 and proxies `/api/*` to the Flask backend (`BACKEND_URL`, default `http://localhost:5000`).

Files:
- `server.js`, `package.json`, `public/index.html` - the application
- `test/server.test.js` - tests with Node's built-in runner (`npm test`)
- `ecosystem.config.js` - pm2 definition
- `Jenkinsfile` - pipeline: Checkout, Install dependencies, Test, Deploy (pm2 restart), Health check

Run locally:
```bash
npm install && npm test
npm start
```

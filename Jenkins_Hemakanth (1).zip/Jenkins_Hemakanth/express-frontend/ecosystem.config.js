// pm2 process definition for the Express frontend (port 3000).
module.exports = {
  apps: [
    {
      name: "express-frontend",
      cwd: __dirname,
      script: "server.js",
      autorestart: true,
      env: {
        PORT: "3000",
        BACKEND_URL: "http://localhost:5000",
        // These two come from the shell that runs pm2 (Jenkins sets them).
        BUILD_NUMBER: process.env.BUILD_NUMBER || "manual",
        APP_SECRET: process.env.APP_SECRET || "",
      },
    },
  ],
};

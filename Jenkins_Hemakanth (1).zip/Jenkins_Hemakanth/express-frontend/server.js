const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
// Where the Flask backend lives (same EC2 instance, so localhost).
const BACKEND_URL = (process.env.BACKEND_URL || "http://localhost:5000").replace(/\/$/, "");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Tells the page which backend it is talking to.
app.get("/config", (req, res) => res.json({ backend: BACKEND_URL }));

app.get("/health", (req, res) =>
  res.json({
    status: "ok",
    // Set by Jenkins when it deploys, so you can see which build is running.
    build: process.env.BUILD_NUMBER || "manual",
    // Shows that a secret from Jenkins credentials reached the app (value is never shown).
    secret_configured: Boolean(process.env.APP_SECRET),
  })
);

// Proxy every /api/* call to the Flask backend.
app.all("/api/*", async (req, res) => {
  try {
    const opts = { method: req.method, headers: { "Content-Type": "application/json" } };
    if (!["GET", "HEAD"].includes(req.method)) opts.body = JSON.stringify(req.body || {});
    const r = await fetch(BACKEND_URL + req.originalUrl, opts);
    const text = await r.text();
    res.status(r.status).type("application/json").send(text);
  } catch (err) {
    res.status(502).json({ error: `Could not reach backend at ${BACKEND_URL}: ${err.message}` });
  }
});

// Only start listening when run directly (so the tests can import the app).
if (require.main === module) {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express frontend on port ${PORT}, backend = ${BACKEND_URL}`);
  });
}

module.exports = app;

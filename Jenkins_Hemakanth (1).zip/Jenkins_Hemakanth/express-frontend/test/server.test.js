// Tests use Node's built-in test runner (no extra packages needed).
const test = require("node:test");
const assert = require("node:assert");
const http = require("node:http");

process.env.BACKEND_URL = "http://127.0.0.1:1"; // nothing listens here, to test the 502 path
const app = require("../server");

let server, base;

test.before(async () => {
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});

test.after(() => server.close());

test("GET /health returns ok", async () => {
  const r = await fetch(base + "/health");
  assert.strictEqual(r.status, 200);
  const j = await r.json();
  assert.strictEqual(j.status, "ok");
});

test("GET /config shows the backend URL", async () => {
  const j = await (await fetch(base + "/config")).json();
  assert.strictEqual(j.backend, "http://127.0.0.1:1");
});

test("GET / serves the HTML page", async () => {
  const r = await fetch(base + "/");
  assert.strictEqual(r.status, 200);
  assert.match(await r.text(), /Express frontend/);
});

test("/api/* returns 502 when the backend is down", async () => {
  const r = await fetch(base + "/api/items");
  assert.strictEqual(r.status, 502);
});

test("secret is never leaked by /health", async () => {
  process.env.APP_SECRET = "super-secret-value";
  const body = await (await fetch(base + "/health")).text();
  assert.ok(!body.includes("super-secret-value"));
  assert.ok(body.includes('"secret_configured":true'));
  delete process.env.APP_SECRET;
});

# Flask frontend + Express backend on Minikube

```
Browser --> frontend-service (NodePort 30080) --> flask-frontend pods (x2, port 5000)
                                                        |
                                                        v  http://backend-service:3001
                                              backend-service (ClusterIP) --> express-backend pods (x2, port 3001)
```

## Project layout

```
backend/    Express app + Dockerfile
frontend/   Flask app + Dockerfile + templates
k8s/        Deployment and Service YAML for each app
```

## 1. Start Minikube

```bash
minikube start --driver=docker
kubectl get nodes
```

## 2. Build the images and load them into Minikube

Minikube v1.39 uses the containerd runtime by default, so build with your normal
Docker and then load the images into the cluster (no registry needed):

```bash
docker build -t express-backend:1.0 ./backend
docker build -t flask-frontend:1.0  ./frontend

minikube image load express-backend:1.0
minikube image load flask-frontend:1.0

minikube image ls | grep -E "express-backend|flask-frontend"
```

## 3. Deploy

Backend first, then frontend:

```bash
kubectl apply -f k8s/backend-deployment.yaml
kubectl apply -f k8s/backend-service.yaml
kubectl apply -f k8s/frontend-deployment.yaml
kubectl apply -f k8s/frontend-service.yaml
```

## 4. Verify

```bash
kubectl get pods
kubectl get deployments
kubectl get services
kubectl get all
```

Pods should show `Running` and `1/1` ready. If one does not:

```bash
kubectl describe pod <pod-name>
kubectl logs <pod-name>
```

## 5. Open the app

```bash
minikube service frontend-service --url
```

Open the printed URL in the browser:

- `/` shows the form. Submitting it redirects to `/success`.
- `/api` shows the JSON list that the Flask pod fetched from the Express pod.

Check that the backend received the submission:

```bash
kubectl logs -l app=express-backend --tail=5
```

## 6. Optional extras

```bash
kubectl scale deployment flask-frontend --replicas=3     # scale up
kubectl delete pod <one-frontend-pod>                    # Kubernetes recreates it
kubectl exec deploy/flask-frontend -- python -c "import urllib.request;print(urllib.request.urlopen('http://backend-service:3001/health').read())"
```

## Clean up

```bash
kubectl delete -f k8s/
minikube stop
```

## Running locally without Kubernetes

```bash
cd backend && npm install && node server.js             # port 3001
cd frontend && pip install -r requirements.txt && BACKEND_URL=http://localhost:3001 python app.py   # port 5000
```

## One-command deploy

```bash
bash deploy.sh      # start minikube if needed, build images, apply manifests, wait for pods
bash cleanup.sh     # delete the app and stop minikube
```

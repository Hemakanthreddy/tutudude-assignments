#!/usr/bin/env bash
# Removes the app from the cluster and stops Minikube.
set -euo pipefail
cd "$(dirname "$0")"
kubectl delete -f k8s/ --ignore-not-found
minikube stop

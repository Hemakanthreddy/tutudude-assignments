#!/usr/bin/env bash
# Builds both images inside Minikube and deploys everything.
# Usage: bash deploy.sh
set -euo pipefail
cd "$(dirname "$0")"

echo ">> Checking Minikube is running"
minikube status >/dev/null 2>&1 || minikube start --driver=docker

echo ">> Building images with the local Docker"
docker build -t express-backend:1.0 ./backend
docker build -t flask-frontend:1.0  ./frontend

echo ">> Loading images into Minikube"
minikube image load express-backend:1.0
minikube image load flask-frontend:1.0

echo ">> Applying manifests"
kubectl apply -f k8s/backend-deployment.yaml
kubectl apply -f k8s/backend-service.yaml
kubectl apply -f k8s/frontend-deployment.yaml
kubectl apply -f k8s/frontend-service.yaml

echo ">> Waiting for pods to be ready"
kubectl rollout status deployment/express-backend --timeout=120s
kubectl rollout status deployment/flask-frontend  --timeout=120s

kubectl get pods
kubectl get services
echo
echo "Open the app with:  minikube service frontend-service --url"

import os

import requests
from flask import Flask, jsonify, redirect, render_template, request, url_for

app = Flask(__name__)

# Inside Kubernetes this is the backend Service DNS name (set in the Deployment).
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:3001")


@app.route("/", methods=["GET", "POST"])
def index():
    error = None
    form_data = {}

    if request.method == "POST":
        form_data = {
            "name": request.form.get("name", "").strip(),
            "email": request.form.get("email", "").strip(),
            "message": request.form.get("message", "").strip(),
        }
        try:
            resp = requests.post(f"{BACKEND_URL}/submit", json=form_data, timeout=5)
            if resp.status_code == 201:
                return redirect(url_for("success"))
            error = resp.json().get("error", f"Backend returned status {resp.status_code}")
        except (requests.RequestException, ValueError) as exc:
            error = f"Could not reach backend: {exc}"

    return render_template("index.html", error=error, form_data=form_data)


@app.route("/success")
def success():
    return render_template("success.html")


@app.route("/api")
def api():
    """Shows data fetched from the Express backend through the Service."""
    try:
        resp = requests.get(f"{BACKEND_URL}/api", timeout=5)
        return jsonify(resp.json()), resp.status_code
    except (requests.RequestException, ValueError) as exc:
        return jsonify({"error": f"Could not reach backend: {exc}"}), 502


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

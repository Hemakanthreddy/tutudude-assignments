const express = require("express");
const os = require("os");

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

const items = [
  { id: 1, name: "Arduino Uno", category: "Microcontroller", price: 550 },
  { id: 2, name: "ESP32 DevKit", category: "IoT Board", price: 450 },
  { id: 3, name: "DHT11 Sensor", category: "Sensor", price: 120 },
  { id: 4, name: "HC-SR04 Ultrasonic", category: "Sensor", price: 90 },
];

// Used by Kubernetes liveness/readiness probes.
// "pod" shows which replica answered (handy to see load balancing).
app.get("/health", (req, res) => {
  res.json({ status: "ok", pod: os.hostname() });
});

app.get("/api", (req, res) => {
  res.json(items);
});

app.post("/submit", (req, res) => {
  const { name, email, message } = req.body || {};
  if (!name || !email || !message) {
    return res.status(400).json({ error: "All fields are required." });
  }
  // Visible with: kubectl logs -l app=express-backend
  console.log(
    `[${new Date().toISOString()}] New submission from ${name} <${email}>: ${message}`
  );
  res.status(201).json({ message: "Data submitted successfully", pod: os.hostname() });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Express backend listening on port ${PORT}`);
});

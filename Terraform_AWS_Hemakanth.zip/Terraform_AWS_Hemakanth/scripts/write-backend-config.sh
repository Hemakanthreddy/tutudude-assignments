#!/usr/bin/env bash
# Reads the bootstrap outputs and writes a backend.hcl into each part,
# so that "terraform init -backend-config=backend.hcl" uses the S3 bucket.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUCKET="$(terraform -chdir="$ROOT/bootstrap" output -raw state_bucket)"
REGION="$(terraform -chdir="$ROOT/bootstrap" output -raw aws_region)"
for part in part1-single-ec2 part2-separate-ec2 part3-ecs-alb; do
  cat > "$ROOT/$part/backend.hcl" <<HCL
bucket       = "$BUCKET"
key          = "$part/terraform.tfstate"
region       = "$REGION"
encrypt      = true
use_lockfile = true
HCL
  echo "wrote $part/backend.hcl"
done

# Flask + Express on AWS with Terraform

Three ways to deploy the same app (Flask backend on port 5000, Express frontend on port 3000):

| Part | Folder | What it builds |
|------|--------|----------------|
| 1 | `part1-single-ec2/` | One EC2 instance running both apps (user-data script, systemd) |
| 2 | `part2-separate-ec2/` | VPC + 2 public subnets + 2 security groups + 2 EC2 instances (one per app) |
| 3 | `part3-ecs-alb/` | VPC, 2 ECR repos, ECS Fargate cluster + 2 services, Application Load Balancer |
| - | `bootstrap/` | The S3 bucket that stores the Terraform state of all three parts |
| - | `app/` | The Flask (`backend/`) and Express (`frontend/`) source with Dockerfiles |

```
Part 1:  Browser -> EC2 [ Express :3000 -> Flask :5000 (localhost) ]

Part 2:  Browser -> Express EC2 :3000 --private IP--> Flask EC2 :5000
         (frontend-sg: 22, 3000 from internet; backend-sg: 22, 5000 from frontend-sg and internet)

Part 3:  Browser -> ALB :80 --/api/*--> Flask target group  -> Fargate task :5000
                            --default-> Express target group -> Fargate task :3000
```

## Terraform best practices used

- Every part has `versions.tf` (pinned Terraform and provider versions), `variables.tf` (all inputs, with defaults and descriptions), `main.tf` and `outputs.tf`.
- No hard-coded AMI ids, account ids or IPs: the AMI comes from an SSM parameter, the account id from `aws_caller_identity`.
- Remote state in S3 (versioned, encrypted, public access blocked) with native state locking (`use_lockfile`).
- Security groups reference each other (`referenced_security_group_id`) instead of copying IP ranges.
- Encrypted root volumes, IMDSv2 required on EC2, ECR image scanning on push, ECR lifecycle policy, CloudWatch log groups created by Terraform, `default_tags` on every resource.

## 0. Prerequisites

The easiest place to run everything is **AWS CloudShell** (the `>_` icon at the top of the AWS console). It already has the AWS CLI, Docker and your login, so no access keys are needed.

1. Open CloudShell in the **Asia Pacific (Sydney) ap-southeast-2** region.
2. Upload this project: **Actions -> Upload file**, choose `Terraform_AWS_Hemakanth.zip`, then:
   ```bash
   unzip Terraform_AWS_Hemakanth.zip
   cd Terraform_AWS_Hemakanth
   ```
3. Install Terraform (version 1.10 or newer):
   ```bash
   sudo yum install -y yum-utils
   sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/AmazonLinux/hashicorp.repo
   sudo yum -y install terraform
   terraform version
   ```

Running on your own Fedora PC instead: install Terraform, the AWS CLI and Docker, run `aws configure` with an IAM user's access key, and use the same commands below.

## 1. Create the state bucket (once)

```bash
cd bootstrap
terraform init
terraform plan
terraform apply          # type yes
cd ..
bash scripts/write-backend-config.sh
```

The script writes a `backend.hcl` file into each part. These point `terraform init` at the S3 bucket.

## 2. Part 1: single EC2

```bash
cd part1-single-ec2
terraform init -backend-config=backend.hcl
terraform fmt && terraform validate
terraform plan
terraform apply          # type yes
terraform output
```

Wait about 2 minutes after apply (the instance installs packages on first boot), then open:

- `express_url` output, for example `http://<public-ip>:3000` (the frontend page)
- `flask_url` output, for example `http://<public-ip>:5000/health`

Check the first-boot log through EC2 Instance Connect with `sudo tail -50 /var/log/app-setup.log`, and the services with `systemctl status flask-backend express-frontend`.

Remove it when finished: `terraform destroy`.

## 3. Part 2: two EC2 instances

```bash
cd ../part2-separate-ec2
terraform init -backend-config=backend.hcl
terraform plan
terraform apply
terraform output
```

- `express_url`: the frontend. Submitting the form shows the Flask response, which proves the two instances talk to each other over the private IP.
- `flask_url`: the backend, open to the internet as the assignment asks.
- Terraform creates the VPC, two subnets, the internet gateway, the route table and both security groups.

Remove it: `terraform destroy`.

## 4. Part 3: Docker, ECR, ECS, ALB

```bash
cd ../part3-ecs-alb
terraform init -backend-config=backend.hcl
terraform plan
terraform apply
terraform output
```

During `apply` Terraform creates the ECR repositories, then runs `docker build` and `docker push` for both images (a `null_resource` with `local-exec`), then creates the cluster, task definitions, services and the load balancer. This takes about 5 to 8 minutes. The machine running Terraform needs Docker and the AWS CLI, and CloudShell has both.

Open the `alb_url` output. The frontend loads through the ALB, and `<alb_url>/api/items` is routed by the listener rule to Flask. Services and tasks can be checked in the console under ECS -> Clusters -> `p3-ecs-cluster`, and images under ECR.

Stop the tasks without deleting anything with `terraform apply -var desired_count=0`. Delete everything with `terraform destroy`.

## 5. Where the state lives

```bash
aws s3 ls s3://$(terraform -chdir=../bootstrap output -raw state_bucket)/ --recursive
```

You will see one `terraform.tfstate` per part (`part1-single-ec2/`, `part2-separate-ec2/`, `part3-ecs-alb/`).

## 6. Clean up everything

Destroy in this order so nothing is left running (and billed):

```bash
cd part3-ecs-alb      && terraform destroy
cd ../part2-separate-ec2 && terraform destroy
cd ../part1-single-ec2   && terraform destroy
cd ../bootstrap       && terraform destroy   # last: this deletes the state bucket
```

Cost note: the ALB and Fargate tasks in Part 3 cost money every hour they exist, so destroy Part 3 as soon as the screenshots are taken.

## Troubleshooting

| Problem | Fix |
|---|---|
| `terraform init` asks for a bucket | Run `bash scripts/write-backend-config.sh` first and pass `-backend-config=backend.hcl` |
| Page does not open right after apply (Part 1/2) | User data is still running; wait 2 minutes and check `/var/log/app-setup.log` |
| `docker: command not found` or push fails (Part 3) | Run from CloudShell, or install Docker and run `aws configure` |
| ECS tasks keep restarting | CloudWatch log groups `/ecs/p3-ecs-flask` and `/ecs/p3-ecs-express` show the error |
| ALB shows 503 right after apply | Tasks are still starting and passing health checks; wait 1 to 2 minutes |
| `Error: creating ... AlreadyExists` after an interrupted run | Run `terraform apply` again, or `terraform destroy` and start over |

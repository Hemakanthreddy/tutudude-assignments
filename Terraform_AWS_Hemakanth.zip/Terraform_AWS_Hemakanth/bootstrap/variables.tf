variable "aws_region" {
  description = "AWS region for the state bucket"
  type        = string
  default     = "ap-southeast-2"
}

variable "project_name" {
  description = "Prefix used in the bucket name"
  type        = string
  default     = "hemakanth"
}

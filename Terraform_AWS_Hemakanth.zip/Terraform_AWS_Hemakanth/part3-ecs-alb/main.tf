provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project   = var.project_name
      ManagedBy = "terraform"
    }
  }
}

data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  # Image tag = hash of the app source, so a code change gives a new image and a new task definition.
  backend_tag  = substr(sha1(join("", [for f in sort(fileset("${path.module}/../app/backend", "**")) : filesha1("${path.module}/../app/backend/${f}")])), 0, 12)
  frontend_tag = substr(sha1(join("", [for f in sort(fileset("${path.module}/../app/frontend", "**")) : filesha1("${path.module}/../app/frontend/${f}")])), 0, 12)
}

# ------------------------------------------------------------------ VPC
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags                 = { Name = "${var.project_name}-vpc" }
}

resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.main.id
  tags   = { Name = "${var.project_name}-igw" }
}

resource "aws_subnet" "public" {
  count                   = 2
  vpc_id                  = aws_vpc.main.id
  cidr_block              = var.public_subnet_cidrs[count.index]
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true
  tags                    = { Name = "${var.project_name}-public-${count.index}" }
}

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.igw.id
  }

  tags = { Name = "${var.project_name}-public-rt" }
}

resource "aws_route_table_association" "public" {
  count          = 2
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

# ------------------------------------------------------- Security groups
resource "aws_security_group" "alb" {
  name        = "${var.project_name}-alb-sg"
  description = "Public HTTP into the load balancer"
  vpc_id      = aws_vpc.main.id
}

resource "aws_vpc_security_group_ingress_rule" "alb_http" {
  security_group_id = aws_security_group.alb.id
  description       = "HTTP from the internet"
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = 80
  to_port           = 80
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "alb_all" {
  security_group_id = aws_security_group.alb.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

resource "aws_security_group" "flask_task" {
  name        = "${var.project_name}-flask-task-sg"
  description = "Flask tasks: only the ALB may connect"
  vpc_id      = aws_vpc.main.id
}

resource "aws_vpc_security_group_ingress_rule" "flask_from_alb" {
  security_group_id            = aws_security_group.flask_task.id
  description                  = "Flask port from the ALB"
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = var.flask_port
  to_port                      = var.flask_port
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "flask_all" {
  security_group_id = aws_security_group.flask_task.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

resource "aws_security_group" "express_task" {
  name        = "${var.project_name}-express-task-sg"
  description = "Express tasks: only the ALB may connect"
  vpc_id      = aws_vpc.main.id
}

resource "aws_vpc_security_group_ingress_rule" "express_from_alb" {
  security_group_id            = aws_security_group.express_task.id
  description                  = "Express port from the ALB"
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = var.express_port
  to_port                      = var.express_port
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "express_all" {
  security_group_id = aws_security_group.express_task.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

# ------------------------------------------------------------------ ECR
resource "aws_ecr_repository" "backend" {
  name         = "${var.project_name}-flask-backend"
  force_delete = true # lets "terraform destroy" delete the repo even if it holds images

  image_scanning_configuration {
    scan_on_push = true
  }
}

resource "aws_ecr_repository" "frontend" {
  name         = "${var.project_name}-express-frontend"
  force_delete = true

  image_scanning_configuration {
    scan_on_push = true
  }
}

resource "aws_ecr_lifecycle_policy" "keep_last_5" {
  for_each   = { backend = aws_ecr_repository.backend.name, frontend = aws_ecr_repository.frontend.name }
  repository = each.value
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep only the 5 newest images"
      selection    = { tagStatus = "any", countType = "imageCountMoreThan", countNumber = 5 }
      action       = { type = "expire" }
    }]
  })
}

# Build both Docker images on the machine running Terraform and push them to ECR.
# Needs: docker and the aws cli, logged in with credentials (CloudShell has both).
resource "null_resource" "push_backend" {
  triggers = {
    tag  = local.backend_tag
    repo = aws_ecr_repository.backend.repository_url
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    command     = <<-EOT
      set -euo pipefail
      aws ecr get-login-password --region ${var.aws_region} | docker login --username AWS --password-stdin ${split("/", aws_ecr_repository.backend.repository_url)[0]}
      docker build --platform linux/amd64 -t ${aws_ecr_repository.backend.repository_url}:${local.backend_tag} ${path.module}/../app/backend
      docker push ${aws_ecr_repository.backend.repository_url}:${local.backend_tag}
    EOT
  }
}

resource "null_resource" "push_frontend" {
  triggers = {
    tag  = local.frontend_tag
    repo = aws_ecr_repository.frontend.repository_url
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    command     = <<-EOT
      set -euo pipefail
      aws ecr get-login-password --region ${var.aws_region} | docker login --username AWS --password-stdin ${split("/", aws_ecr_repository.frontend.repository_url)[0]}
      docker build --platform linux/amd64 -t ${aws_ecr_repository.frontend.repository_url}:${local.frontend_tag} ${path.module}/../app/frontend
      docker push ${aws_ecr_repository.frontend.repository_url}:${local.frontend_tag}
    EOT
  }
}

# ------------------------------------------------------------------ IAM
data "aws_iam_policy_document" "ecs_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

# Lets ECS pull images from ECR and write logs to CloudWatch.
resource "aws_iam_role" "task_execution" {
  name               = "${var.project_name}-task-execution-role"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume.json
}

resource "aws_iam_role_policy_attachment" "task_execution" {
  role       = aws_iam_role.task_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# ----------------------------------------------------------------- Logs
resource "aws_cloudwatch_log_group" "backend" {
  name              = "/ecs/${var.project_name}-flask"
  retention_in_days = var.log_retention_days
}

resource "aws_cloudwatch_log_group" "frontend" {
  name              = "/ecs/${var.project_name}-express"
  retention_in_days = var.log_retention_days
}

# ------------------------------------------------------------------ ALB
resource "aws_lb" "main" {
  name               = "${var.project_name}-alb"
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = aws_subnet.public[*].id
}

resource "aws_lb_target_group" "frontend" {
  name        = "${var.project_name}-express-tg"
  port        = var.express_port
  protocol    = "HTTP"
  target_type = "ip" # required for Fargate
  vpc_id      = aws_vpc.main.id

  health_check {
    path                = "/health"
    matcher             = "200"
    interval            = 15
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }
}

resource "aws_lb_target_group" "backend" {
  name        = "${var.project_name}-flask-tg"
  port        = var.flask_port
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = aws_vpc.main.id

  health_check {
    path                = "/health"
    matcher             = "200"
    interval            = 15
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }
}

# Default: everything goes to the Express frontend.
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.main.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.frontend.arn
  }
}

# /api/* goes straight to the Flask backend.
resource "aws_lb_listener_rule" "api" {
  listener_arn = aws_lb_listener.http.arn
  priority     = 10

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.backend.arn
  }

  condition {
    path_pattern {
      values = ["/api/*"]
    }
  }
}

# ------------------------------------------------------------------ ECS
resource "aws_ecs_cluster" "main" {
  name = "${var.project_name}-cluster"

  setting {
    name  = "containerInsights"
    value = "disabled"
  }
}

resource "aws_ecs_task_definition" "backend" {
  family                   = "${var.project_name}-flask"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.task_cpu
  memory                   = var.task_memory
  execution_role_arn       = aws_iam_role.task_execution.arn

  container_definitions = jsonencode([{
    name         = "flask-backend"
    image        = "${aws_ecr_repository.backend.repository_url}:${local.backend_tag}"
    essential    = true
    portMappings = [{ containerPort = var.flask_port, protocol = "tcp" }]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.backend.name
        awslogs-region        = var.aws_region
        awslogs-stream-prefix = "flask"
      }
    }
  }])

  depends_on = [null_resource.push_backend]
}

resource "aws_ecs_task_definition" "frontend" {
  family                   = "${var.project_name}-express"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.task_cpu
  memory                   = var.task_memory
  execution_role_arn       = aws_iam_role.task_execution.arn

  container_definitions = jsonencode([{
    name         = "express-frontend"
    image        = "${aws_ecr_repository.frontend.repository_url}:${local.frontend_tag}"
    essential    = true
    portMappings = [{ containerPort = var.express_port, protocol = "tcp" }]
    environment = [
      { name = "PORT", value = tostring(var.express_port) },
      # The ALB sends /api/* to Flask, so the backend is reached through the ALB's own address.
      { name = "BACKEND_URL", value = "http://${aws_lb.main.dns_name}" },
    ]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.frontend.name
        awslogs-region        = var.aws_region
        awslogs-stream-prefix = "express"
      }
    }
  }])

  depends_on = [null_resource.push_frontend]
}

resource "aws_ecs_service" "backend" {
  name            = "flask-backend-service"
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.backend.arn
  desired_count   = var.desired_count
  launch_type     = "FARGATE"

  network_configuration {
    subnets          = aws_subnet.public[*].id
    security_groups  = [aws_security_group.flask_task.id]
    assign_public_ip = true # public subnets without NAT: needed to pull the image from ECR
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.backend.arn
    container_name   = "flask-backend"
    container_port   = var.flask_port
  }

  depends_on = [aws_lb_listener.http, aws_lb_listener_rule.api, aws_iam_role_policy_attachment.task_execution]
}

resource "aws_ecs_service" "frontend" {
  name            = "express-frontend-service"
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.frontend.arn
  desired_count   = var.desired_count
  launch_type     = "FARGATE"

  network_configuration {
    subnets          = aws_subnet.public[*].id
    security_groups  = [aws_security_group.express_task.id]
    assign_public_ip = true
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.frontend.arn
    container_name   = "express-frontend"
    container_port   = var.express_port
  }

  depends_on = [aws_lb_listener.http, aws_lb_listener_rule.api, aws_iam_role_policy_attachment.task_execution]
}

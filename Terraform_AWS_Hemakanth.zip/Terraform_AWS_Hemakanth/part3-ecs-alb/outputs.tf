output "alb_url" {
  description = "Open this in the browser (Express frontend through the ALB)"
  value       = "http://${aws_lb.main.dns_name}"
}

output "flask_health_url" {
  description = "Flask backend through the ALB path rule /api/*"
  value       = "http://${aws_lb.main.dns_name}/api/items"
}

output "ecr_backend_repository_url" {
  value = aws_ecr_repository.backend.repository_url
}

output "ecr_frontend_repository_url" {
  value = aws_ecr_repository.frontend.repository_url
}

output "ecs_cluster_name" {
  value = aws_ecs_cluster.main.name
}

output "vpc_id" {
  value = aws_vpc.main.id
}

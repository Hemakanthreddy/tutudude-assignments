variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "ap-southeast-2"
}

variable "project_name" {
  description = "Name prefix for all resources"
  type        = string
  default     = "p3-ecs"
}

variable "vpc_cidr" {
  type    = string
  default = "10.1.0.0/16"
}

variable "public_subnet_cidrs" {
  description = "Two public subnets in two AZs (the ALB needs two)"
  type        = list(string)
  default     = ["10.1.1.0/24", "10.1.2.0/24"]
}

variable "flask_port" {
  type    = number
  default = 5000
}

variable "express_port" {
  type    = number
  default = 3000
}

variable "task_cpu" {
  description = "Fargate CPU units per task"
  type        = number
  default     = 256
}

variable "task_memory" {
  description = "Fargate memory (MiB) per task"
  type        = number
  default     = 512
}

variable "desired_count" {
  description = "Number of tasks per service. Set to 0 to stop the app without destroying anything."
  type        = number
  default     = 1
}

variable "log_retention_days" {
  type    = number
  default = 7
}

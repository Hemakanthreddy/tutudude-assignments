provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project   = var.project_name
      ManagedBy = "terraform"
    }
  }
}

data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

data "aws_availability_zones" "available" {
  state = "available"
}

# ---------------------------------------------------------------- Networking
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags                 = { Name = "${var.project_name}-vpc" }
}

resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.main.id
  tags   = { Name = "${var.project_name}-igw" }
}

# Subnet 0 holds the frontend, subnet 1 holds the backend (different AZs).
resource "aws_subnet" "public" {
  count                   = 2
  vpc_id                  = aws_vpc.main.id
  cidr_block              = var.public_subnet_cidrs[count.index]
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true
  tags                    = { Name = "${var.project_name}-public-${count.index}" }
}

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.igw.id
  }

  tags = { Name = "${var.project_name}-public-rt" }
}

resource "aws_route_table_association" "public" {
  count          = 2
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

# ---------------------------------------------------------- Security groups
resource "aws_security_group" "frontend" {
  name        = "${var.project_name}-frontend-sg"
  description = "Express frontend: SSH + port 3000 from the internet"
  vpc_id      = aws_vpc.main.id
}

resource "aws_security_group" "backend" {
  name        = "${var.project_name}-backend-sg"
  description = "Flask backend: SSH + port 5000"
  vpc_id      = aws_vpc.main.id
}

# frontend-sg
resource "aws_vpc_security_group_ingress_rule" "frontend_ssh" {
  security_group_id = aws_security_group.frontend.id
  description       = "SSH"
  cidr_ipv4         = var.ssh_cidr
  from_port         = 22
  to_port           = 22
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "frontend_http" {
  security_group_id = aws_security_group.frontend.id
  description       = "Express app, public"
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = var.express_port
  to_port           = var.express_port
  ip_protocol       = "tcp"
}

# backend-sg
resource "aws_vpc_security_group_ingress_rule" "backend_ssh" {
  security_group_id = aws_security_group.backend.id
  description       = "SSH"
  cidr_ipv4         = var.ssh_cidr
  from_port         = 22
  to_port           = 22
  ip_protocol       = "tcp"
}

# Communication between the two instances: the backend accepts port 5000 from the frontend's security group.
resource "aws_vpc_security_group_ingress_rule" "backend_from_frontend" {
  security_group_id            = aws_security_group.backend.id
  description                  = "Flask from the Express instance"
  referenced_security_group_id = aws_security_group.frontend.id
  from_port                    = var.flask_port
  to_port                      = var.flask_port
  ip_protocol                  = "tcp"
}

# The assignment also asks to expose Flask to the internet.
resource "aws_vpc_security_group_ingress_rule" "backend_public" {
  security_group_id = aws_security_group.backend.id
  description       = "Flask, public"
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = var.flask_port
  to_port           = var.flask_port
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "frontend_all" {
  security_group_id = aws_security_group.frontend.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

resource "aws_vpc_security_group_egress_rule" "backend_all" {
  security_group_id = aws_security_group.backend.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

# ---------------------------------------------------------------- Instances
resource "aws_instance" "backend" {
  ami                    = data.aws_ssm_parameter.al2023.value
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public[1].id
  vpc_security_group_ids = [aws_security_group.backend.id]
  key_name               = var.key_name

  user_data_base64 = base64gzip(templatefile("${path.module}/templates/backend.sh.tftpl", {
    flask_port     = var.flask_port
    backend_app_py = file("${path.module}/../app/backend/app.py")
    backend_reqs   = file("${path.module}/../app/backend/requirements.txt")
  }))
  user_data_replace_on_change = true

  metadata_options {
    http_tokens = "required"
  }

  root_block_device {
    volume_size = 8
    volume_type = "gp3"
    encrypted   = true
  }

  tags = { Name = "${var.project_name}-backend" }
}

resource "aws_instance" "frontend" {
  ami                    = data.aws_ssm_parameter.al2023.value
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public[0].id
  vpc_security_group_ids = [aws_security_group.frontend.id]
  key_name               = var.key_name

  # The frontend is told the backend's PRIVATE ip. Referencing it here makes
  # Terraform create the backend instance first.
  user_data_base64 = base64gzip(templatefile("${path.module}/templates/frontend.sh.tftpl", {
    express_port     = var.express_port
    backend_url      = "http://${aws_instance.backend.private_ip}:${var.flask_port}"
    frontend_server  = file("${path.module}/../app/frontend/server.js")
    frontend_package = file("${path.module}/../app/frontend/package.json")
    frontend_index   = file("${path.module}/../app/frontend/public/index.html")
  }))
  user_data_replace_on_change = true

  metadata_options {
    http_tokens = "required"
  }

  root_block_device {
    volume_size = 8
    volume_type = "gp3"
    encrypted   = true
  }

  tags = { Name = "${var.project_name}-frontend" }
}

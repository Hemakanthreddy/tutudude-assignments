output "vpc_id" {
  value = aws_vpc.main.id
}

output "backend_public_ip" {
  value = aws_instance.backend.public_ip
}

output "backend_private_ip" {
  value = aws_instance.backend.private_ip
}

output "frontend_public_ip" {
  value = aws_instance.frontend.public_ip
}

output "express_url" {
  description = "Open this in the browser (Express frontend)"
  value       = "http://${aws_instance.frontend.public_ip}:${var.express_port}"
}

output "flask_url" {
  description = "Flask backend health check"
  value       = "http://${aws_instance.backend.public_ip}:${var.flask_port}/health"
}

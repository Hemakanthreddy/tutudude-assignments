variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "ap-southeast-2"
}

variable "project_name" {
  description = "Name prefix for all resources"
  type        = string
  default     = "p1-single-ec2"
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.micro"
}

variable "key_name" {
  description = "Optional EC2 key pair name for SSH. Leave null to use EC2 Instance Connect only."
  type        = string
  default     = null
}

variable "ssh_cidr" {
  description = "CIDR allowed to reach SSH (22). 0.0.0.0/0 lets EC2 Instance Connect work from the console."
  type        = string
  default     = "0.0.0.0/0"
}

variable "flask_port" {
  description = "Port of the Flask backend"
  type        = number
  default     = 5000
}

variable "express_port" {
  description = "Port of the Express frontend"
  type        = number
  default     = 3000
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project   = var.project_name
      ManagedBy = "terraform"
    }
  }
}

# Latest Amazon Linux 2023 AMI (looked up, so no AMI id is hard-coded).
data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

# Use the default VPC and one of its subnets for this simple part.
data "aws_vpc" "default" {
  default = true
}

data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

resource "aws_security_group" "app" {
  name        = "${var.project_name}-sg"
  description = "SSH, Flask and Express"
  vpc_id      = data.aws_vpc.default.id
}

resource "aws_vpc_security_group_ingress_rule" "ssh" {
  security_group_id = aws_security_group.app.id
  description       = "SSH"
  cidr_ipv4         = var.ssh_cidr
  from_port         = 22
  to_port           = 22
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "express" {
  security_group_id = aws_security_group.app.id
  description       = "Express frontend"
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = var.express_port
  to_port           = var.express_port
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "flask" {
  security_group_id = aws_security_group.app.id
  description       = "Flask backend"
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = var.flask_port
  to_port           = var.flask_port
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "all" {
  security_group_id = aws_security_group.app.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

resource "aws_instance" "app" {
  ami                         = data.aws_ssm_parameter.al2023.value
  instance_type               = var.instance_type
  subnet_id                   = data.aws_subnets.default.ids[0]
  vpc_security_group_ids      = [aws_security_group.app.id]
  associate_public_ip_address = true
  key_name                    = var.key_name

  # The user-data script installs Python + Node.js, writes both apps and
  # starts them as systemd services. It is gzip-compressed to stay under 16 KB.
  user_data_base64 = base64gzip(templatefile("${path.module}/templates/user-data.sh.tftpl", {
    flask_port       = var.flask_port
    express_port     = var.express_port
    backend_app_py   = file("${path.module}/../app/backend/app.py")
    backend_reqs     = file("${path.module}/../app/backend/requirements.txt")
    frontend_server  = file("${path.module}/../app/frontend/server.js")
    frontend_package = file("${path.module}/../app/frontend/package.json")
    frontend_index   = file("${path.module}/../app/frontend/public/index.html")
  }))
  user_data_replace_on_change = true

  metadata_options {
    http_tokens = "required" # IMDSv2 only
  }

  root_block_device {
    volume_size = 8
    volume_type = "gp3"
    encrypted   = true
  }

  tags = {
    Name = "${var.project_name}-server"
  }
}

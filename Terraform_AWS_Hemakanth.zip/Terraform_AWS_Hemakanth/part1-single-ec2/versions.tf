terraform {
  required_version = ">= 1.10"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.60"
    }
  }

  # Remote state in S3. The bucket name is not hard-coded here;
  # it comes from backend.hcl (see scripts/write-backend-config.sh).
  backend "s3" {}
}

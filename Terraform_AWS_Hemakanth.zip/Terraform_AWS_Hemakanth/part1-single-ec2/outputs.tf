output "instance_id" {
  value = aws_instance.app.id
}

output "public_ip" {
  value = aws_instance.app.public_ip
}

output "express_url" {
  description = "Open this in the browser (Express frontend)"
  value       = "http://${aws_instance.app.public_ip}:${var.express_port}"
}

output "flask_url" {
  description = "Flask backend health check"
  value       = "http://${aws_instance.app.public_ip}:${var.flask_port}/health"
}

#!/usr/bin/env bash
# Build both images and push them to ECR.
# Usage: bash deploy/ecs/ecr-push.sh <AWS_REGION>     (AWS CLI must be configured: aws configure)
set -euo pipefail
REGION="${1:?usage: ecr-push.sh <aws-region>, e.g. ap-south-1}"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
REGISTRY="$ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com"
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"

for repo in flask-backend express-frontend; do
  aws ecr describe-repositories --repository-names "$repo" --region "$REGION" >/dev/null 2>&1 \
    || aws ecr create-repository --repository-name "$repo" --region "$REGION"
done

aws ecr get-login-password --region "$REGION" | docker login --username AWS --password-stdin "$REGISTRY"

docker build -t flask-backend    "$ROOT/backend"
docker build -t express-frontend "$ROOT/frontend"

docker tag flask-backend:latest    "$REGISTRY/flask-backend:latest"
docker tag express-frontend:latest "$REGISTRY/express-frontend:latest"
docker push "$REGISTRY/flask-backend:latest"
docker push "$REGISTRY/express-frontend:latest"

echo "Pushed. Account=$ACCOUNT_ID Region=$REGION"

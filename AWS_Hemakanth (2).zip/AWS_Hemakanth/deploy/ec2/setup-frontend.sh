#!/usr/bin/env bash
# Installs and starts the Express frontend as a systemd service (port 3000).
# Usage:
#   single EC2 :  bash deploy/ec2/setup-frontend.sh http://localhost:5000
#   two EC2s   :  bash deploy/ec2/setup-frontend.sh http://<BACKEND_PRIVATE_IP>:5000
set -euo pipefail
BACKEND_URL="${1:-http://localhost:5000}"
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/frontend"
npm install --omit=dev

sudo tee /etc/systemd/system/express-frontend.service >/dev/null <<UNIT
[Unit]
Description=Express frontend
After=network.target

[Service]
User=$USER
WorkingDirectory=$ROOT/frontend
Environment=PORT=3000
Environment=BACKEND_URL=$BACKEND_URL
ExecStart=$(command -v node) server.js
Restart=always

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable --now express-frontend
sleep 2
systemctl --no-pager status express-frontend | head -5
curl -s http://localhost:3000/health; echo

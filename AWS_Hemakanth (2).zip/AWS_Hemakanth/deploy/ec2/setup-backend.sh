#!/usr/bin/env bash
# Installs and starts the Flask backend as a systemd service (port 5000).
# Run from anywhere:  bash deploy/ec2/setup-backend.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/backend"
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

sudo tee /etc/systemd/system/flask-backend.service >/dev/null <<UNIT
[Unit]
Description=Flask backend
After=network.target

[Service]
User=$USER
WorkingDirectory=$ROOT/backend
ExecStart=$ROOT/backend/venv/bin/gunicorn --bind 0.0.0.0:5000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable --now flask-backend
sleep 2
systemctl --no-pager status flask-backend | head -5
curl -s http://localhost:5000/health; echo

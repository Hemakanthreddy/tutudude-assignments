#!/usr/bin/env bash
# Run once on an Amazon Linux 2023 EC2 instance.
set -euo pipefail
sudo dnf update -y
sudo dnf install -y git python3 python3-pip
# Node.js 20 (the frontend uses the built-in fetch)
curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
sudo dnf install -y nodejs
python3 --version; node --version; npm --version; git --version

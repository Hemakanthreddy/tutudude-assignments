const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
// Where the Flask backend lives. Set per deployment:
//   single EC2   -> http://localhost:5000
//   two EC2s     -> http://<BACKEND_PRIVATE_IP>:5000
//   ECS (1 task) -> http://localhost:5000
const BACKEND_URL = (process.env.BACKEND_URL || "http://localhost:5000").replace(/\/$/, "");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Tells the page which backend it is talking to (useful for screenshots).
app.get("/config", (req, res) => res.json({ backend: BACKEND_URL }));

app.get("/health", (req, res) => res.json({ status: "ok" }));

// Proxy every /api/* call to the Flask backend, so the browser only ever
// talks to the frontend (no CORS, and the backend can stay private).
app.all("/api/*", async (req, res) => {
  try {
    const opts = { method: req.method, headers: { "Content-Type": "application/json" } };
    if (!["GET", "HEAD"].includes(req.method)) opts.body = JSON.stringify(req.body || {});
    const r = await fetch(BACKEND_URL + req.originalUrl, opts);
    const text = await r.text();
    res.status(r.status).type("application/json").send(text);
  } catch (err) {
    res.status(502).json({ error: `Could not reach backend at ${BACKEND_URL}: ${err.message}` });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Express frontend on port ${PORT}, backend = ${BACKEND_URL}`);
});
